﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorController : MonoBehaviour
{
    public GameObject bookshelf;
    public bool bookshelfIsOpening;


    // Update is called once per frame
    void Update()
    {
        if(bookshelfIsOpening == true)
        {
            bookshelf.transform.Translate(Vector3.up * Time.deltaTime * 5);
            //if the bool is true open the bookshelf

        }
        if(bookshelf.transform.position.y > 7f)
        {
            bookshelfIsOpening = false;
            //if the y of the bookshelf is > than 7 we want to stop the bookshelf
        }
    }

    private void OnMouseDown()
    {
        bookshelfIsOpening = true;
        // if we click on the button the bookshelf must open

    }
}
